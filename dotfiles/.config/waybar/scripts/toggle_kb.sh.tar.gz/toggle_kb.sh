#!/usr/bin/env bash
current=$(hyprctl devices | grep -A3 'main: yes' | grep 'l "' | cut -d'"' -f2)
if [ "$current" = "us" ]; then
    hyprctl dispatch input "at-translated-set-2-keyboard" setxkb "ua"
else
    hyprctl dispatch input "at-translated-set-2-keyboard" setxkb "us"
fi

