#!/usr/bin/env bash

# Get current layout index
current=$(hyprctl getoption input:kb_layout | awk -F',' '{print $1}')
layouts=("us" "ua")   # your configured layouts
next=""

# find the next layout
for i in "${!layouts[@]}"; do
    if [[ "${layouts[$i]}" == "$current" ]]; then
        next_index=$(( (i+1) % ${#layouts[@]} ))
        next="${layouts[$next_index]}"
        break
    fi
done

# set the next layout
hyprctl dispatch input 0 setxkbmap "$next"

